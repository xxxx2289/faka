# API mapping from the uploaded ACG-Faka source

These paths were found in the uploaded `acg-faka-main` source tree. Admin APIs require the server's existing admin session and applicable controller interceptors.

| Mobile feature | Endpoint | Method | Current client behavior |
|---|---|---|---|
| Admin login | `/admin/api/authentication/login` | POST | Implemented, includes captcha and optional TOTP |
| Admin captcha | `/user/captcha/image?action=adminLogin` | GET | Implemented |
| Plugin list | `/admin/api/plugin/getPlugins` | GET | Implemented |
| Plugin config/status | `/admin/api/plugin/setConfig?id=<plugin-id>` | POST | Status toggle implemented |
| Orders | `/admin/api/order/data` | POST | Read-only list |
| Commodities | `/admin/api/commodity/data` | POST | Read-only list |
| Cards | `/admin/api/card/data` | POST | Read-only list; card secret fields are not displayed |
| Users | `/admin/api/user/data` | POST | Read-only list |
| Management logs | `/admin/api/log/data` | POST | Read-only list |

## Mobile version and announcement API

The uploaded source does not currently define `/mobile-api/v1/bootstrap`. Before implementing forced update or forced announcement, add a dedicated public read-only endpoint for version/announcement data and a separate owner-only management interface. Do not expose arbitrary file writes or let the public endpoint modify settings. Keep the policy in a server-side configuration file or database record with validation and access control.
