# ACG-Faka Native Android Admin (v0.3.0)

A native Kotlin + Jetpack Compose Android client for an already deployed ACG-Faka instance. This project is not a PHP server replacement and does not embed the ACG-Faka website source into the APK.

## Implemented in this iteration

- HTTPS server root URL configuration (saved locally on the device).
- Native login form using the existing `/user/captcha/image?action=adminLogin` image endpoint and `/admin/api/authentication/login` login API.
- In-memory cookie/session handling for the server's existing admin session.
- Native plugin list from `/admin/api/plugin/getPlugins` and enable/disable through `/admin/api/plugin/setConfig?id=<plugin>`.
- Read-only paginated lists for orders, commodities, cards, users, and management logs, using the existing controller endpoints found in the uploaded source archive.
- GitHub Actions workflow that installs Gradle 8.9 and produces a debug APK artifact.

## Not yet complete

- The app does not yet implement all edit/create/delete/export operations for every module. The non-plugin data pages are currently read-only.
- Website settings are deliberately not written yet: the current `Config::setting` endpoint is a POST save operation requiring a complete validated settings payload. Sending a partial or guessed payload could alter the live shop configuration.
- The uploaded source does not contain the proposed public `/mobile-api/v1/bootstrap` endpoint. Forced update and configurable forced announcements require a server-side adapter and a protected way to edit the policy. The current app identifies this as pending instead of falsely reporting it as active.
- The APK has not been built or device-tested in this environment. Use GitHub Actions to build and inspect the log before installing it.

## Build APK with GitHub Actions

1. Create a GitHub repository and upload the **contents** of this project folder to the repository root (so `app/`, `build.gradle.kts`, `settings.gradle.kts`, and `.github/` are at the root).
2. Open **Actions → Build Android APK → Run workflow**.
3. Wait for the run to finish successfully.
4. Download the `acg-faka-mobile-debug-apk` artifact and extract `app-debug.apk`.
5. Install it on your Android phone. This is a debug APK; a production release should use a private signing key and a release build.

## Security notes

- Use HTTPS and a trusted certificate. The client rejects plain HTTP by design.
- Login cookies are held in memory and are cleared when you press logout; passwords are not persisted.
- Do not upload server `.env`, database backups, payment secrets, admin passwords, or customer data to the GitHub repository.
- Keep the ACG-Faka server patched. The APK should use the server's existing authentication and permission checks, not direct database access.


## v0.3.2 会话修复

ACG-Faka 的后台 `ManageSession` 中间件会校验 API 请求的 `Referer` 主机。原生 HTTP 客户端默认不自动携带浏览器 `Referer`，导致登录成功后调用后台 API 时被提示“当前页面会话失效，请刷新网页”。本版本在验证码、登录和管理 API 请求中添加与服务器同源的 Referer/Origin，并把插件列表请求改为 POST，同时提交 `equal-status` 和 `keywords` 参数。此修复仍需在目标服务器上通过真实登录和各模块操作验证。
